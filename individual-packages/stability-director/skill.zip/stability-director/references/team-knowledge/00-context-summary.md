# 用户上下文摘要（团队知识基线）

版本：2.4.0-rc1。本文档为辽宁移动 CRM 稳定性专家团的"用户上下文基线"，由人工维护；不是本轮逐字现场核验的产物，不作为现场证据使用。

> **纪律红线**（与 stability-director SKILL.md 第 26 行「知识文档不是本次现场证据」一致）：
> 本文及配套 [01-knowledge-index.md](01-knowledge-index.md) 列出的所有素材，**只能作为 `reference_basis` / baseline_relation / comparison_scope 等判断依据字段的输入**，不能直接作为 E 编号现场证据。具体规则见 [02-discipline.md](02-discipline.md)。

## 1. 用户身份（用于写出口径一致的取证请求）

| 字段 | 值 | 取证请求示例 |
|---|---|---|
| 姓名 | 哲哥（沟通称呼） | — |
| 工作单位 | 中国移动通信集团辽宁有限公司 | "请提供辽宁移动侧的..." |
| 业务归属 | 4A 平台运维 / ncrm CRM 运维支撑 | "请提供 4A 平台 / ncrm CRM 侧的..." |
| 所属乙方 | 亚信-运维（部门标识） | — |
| 用户 ID | 5001902 | 必要时作为审计字段 |
| 工号 billid | 15734064118 | — |
| 工位城市 | 沈阳 | "沈阳节点 vs 大区节点"对照口径 |
| 工作环境 | Windows 10 + Git Bash + Python 3.12/3.13 + agent-browser (Chrome CDP) | 取证脚本产物格式（Windows 路径、UTF-8/GBK 混编） |

> 涉及其他 4A 账号（白松/王珊珊/金鑫/张洪宇 等）属委托协助范围；取证请求中应使用原始账号标识，不替换为哲哥本人。

## 2. 业务系统栈（用于路由与口径）

| 层 | 系统 | 版本 / 数量 | 关键参数 |
|---|---|---|---|
| 入口平台 | 辽宁移动 4A 管理平台 | 两个域：portal.4a.ln.cmcc（主门户）/ :8090（管理平台） | 跨域 CORS 受限；CREATEmessage userName 格式 "姓名/账号名" |
| 业务核心 | ncrm CRM 系统 | Java/Spring，13 模块 | — |
| 缓存 | Redis | 三主三从集群；含 aicache 5001、session 6001、业务 7001、产品缓存 8001、统一认证 4001、API 网关 9001、提醒中心 3001 等多个实例 | maxmemory、repl-backlog-size、持久化策略 |
| 服务路由 | ZooKeeper | 3.4.13，5 节点 | syncLimit、initLimit、maxClientCnxns、dataLogDir 分盘、ACL、4lw 白名单 |
| 反向代理 | nginx | 多节点 | 性能指标 + 异常点定位 |
| 其他中间件 | Memcached / Easy-DNS / 后台进程 jar 热发 | — | — |
| 外围 | 计费 / 经分 / 一级能开 / 营业厅网关 / 渠道系统 | — | B 域 / M 域边界 |

## 3. 常用工具与排障习惯（用于产出可执行的取证清单）

| 工具 | 用途 | 取证产物格式 |
|---|---|---|
| Git Bash (Windows) | 文件操作、grep/sed/awk | 行号 + UTF-8 文本 |
| Python 3.12 / 3.13 | 脚本批处理、log 解析 | py 文件 + json/csv 报告 |
| agent-browser (Chrome CDP) | 4A 门户自动化操作、解锁、导航 | 截图 + 控制台日志 + 操作序列 |
| log4x-web（统一日志平台） | 按 trace / aifgw 索引定位调用链 | Kibana 查询条件 + 时间窗口 |
| SecureCRT | SSH 登录验证 | 终端回显 |
| 4A 平台「金库」弹窗 | 自动跳过（多页遍历时） | 操作步骤 |

> 涉及账号密码与验证码：由用户人工输入，AI 严禁代输。

## 4. 工作风格（用于决定报告与建议的颗粒度）

| 偏好 | 表现 | 取证/报告含义 |
|---|---|---|
| 中文 + 表格形式 | 结构化呈现（success/skipped/failed 等量化指标） | 表格 + 量化指标 + 严重度分级 |
| "命令 + 详细参数列表" | 明确列出数据库、日期、账号等 | 报告里允许直接给"用户人工执行"的具体步骤，但不给"AI 自动执行"命令 |
| 增量改进 P0/P1/P2/P3 | 分级逐项落地 | 不一次性给完美方案；按 P0 阻断 → P1 高优 → P2 中优 → P3 长期 排序 |
| 严重度分级 高/中/低 | 定位点 + 影响范围 + 可执行修复步骤 | 报告每条问题带 severity / location / impact / fix 四栏 |
| MMX 交叉验证 | 修复/优化后调用 MMX 模型复核 | AI 建议落地前需 MMX 通过；不接受盲从 |
| 端到端冒烟测试 | scaffold → render → verify | 技能迁移类任务的标准验收手段 |
| 分阶段决策 | AI 如实汇报、给选项让用户拍板 | 报告末尾用"建议二选一"或"下一步等拍板"收口 |

## 5. 知识库入口指针

用户维护的本地 AI 知识库根目录：

```
D:\qoder\ai-knowledge-base\
├── raw/                          ← 用户只投喂这里（GBK/UTF-8 混编注意）
│   ├── 00-能力开放平台/          ← 故障分析、CRM 系统、API 网关知识库、生产架构等
│   ├── 01-tools/                 ← 工具文档
│   └── 02-相关故障/              ← 事故素材（7 个 INDEX.md 见 01-knowledge-index.md）
├── wiki/                         ← LLM 管理的 concept / source / archive（只读不写）
├── outputs/                      ← LLM 产生的 Q&A、报告、charts
└── .kb/                          ← LLM 状态（manifest / search_index / 脚本）
```

> **路径处理规则**：
> - 路径在不同机器会变（如 Mac mini 用 `~/ai-knowledge-base/`，Windows 用 `D:\qoder\ai-knowledge-base\`）。
> - 取证/分析时应让用户确认当前工作目录，不要硬编码绝对路径。
> - 知识库内容**单份维护**：本目录（expert 包内）只放精选摘要 + 路径指针，原始素材继续在用户仓库演进。

## 6. 与现有 references 的关系

| 现有文档 | 关系 |
|---|---|
| [telecom-crm-knowledge.md](../telecom-crm-knowledge.md) | 业务链路专家的标准 runbook；本目录是其用户上下文层 |
| [linux-runbook.md](../linux-runbook.md) | Linux 基础设施专家的标准 runbook；本目录补充辽宁移动栈细节 |
| [oracle-runbook.md](../oracle-runbook.md) | Oracle DBA 专家的标准 runbook；本目录补充 ncrm CRM 数据库清单 |
| [app-jvm-runbook.md](../app-jvm-runbook.md) | Java/JVM 专家的标准 runbook；本目录补充 Spring 13 模块结构 |
| [observability-runbook.md](../observability-runbook.md) | 监控专家的标准 runbook；本目录补充 log4x 平台用法 |
| [change-capacity-dr.md](../change-capacity-dr.md) | 变更容量专家的标准 runbook；本目录补充 4A 平台变更流程 |
| [k8s-platform-runbook.md](../k8s-platform-runbook.md) | K8s 专家的标准 runbook；本目录补充辽宁移动部署上下文 |

本目录**不替代**现有 runbook，只在 runbook 之上叠加用户/环境层。成员接报时先读各自领域的 runbook，再读本目录的 00/01/02。
