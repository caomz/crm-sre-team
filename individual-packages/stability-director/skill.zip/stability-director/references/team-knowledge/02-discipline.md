# 团队知识引用纪律（reference_basis vs 现场证据）

版本：2.4.0-rc1。本文定义专家团在使用 [00-context-summary.md](00-context-summary.md) 与 [01-knowledge-index.md](01-knowledge-index.md) 时的纪律红线。

> **总原则**：用户 ai-knowledge-base 仓库里的所有内容（手册、配置、历史事故、监控/告警产物），都是**参考基线 / 历史窗口 / 相邻对象**，**不是本次现场证据**。
> 现场证据由宿主账本分配 E 编号（详见 stability-director SKILL.md「证据与四象限」第 26 行）。

## 1. 三种引用场景的边界

| 场景 | 引用方式 | 四象限字段 | 错误示例 |
|---|---|---|---|
| 建立"正常时段"基线 | 引用手册/配置作为对照 | `reference_basis.reference_type = "baseline_documentation"` | 把手册里的端口号当成"事故现场"端口号 |
| 引用"相邻对象"对照 | 引用历史事故的现象/参数 | `reference_basis.reference_type = "adjacent_incident"` + `comparison_scope` 写明对比对象 | 把历史事故的根因当成当前事故的根因 |
| 引用"知识库缺口"催取证 | 引用 INDEX 缺口清单 | `request_proposals.target_baseline_gap = "..."` | 因为"知识库没记"就默认"未发生"或"已排除" |

## 2. reference_basis 字段填写范式

每位成员的 `evidence_effects[*].reference_basis` 应按以下五项填写（与 stability-director SKILL.md 第 48 行「判断依据协议」一致）：

```yaml
- effect: SUPPORTS | WEAKENS | NEUTRAL | UNKNOWN
  expected_if_true: "候选为真时这条证据应常见的现象"
  expected_if_false: "候选为假时这条证据是否仍常见；无依据写 UNKNOWN"
  reference_basis:
    reference_type: "baseline_documentation" | "adjacent_incident" | "historical_window" | "knowledge_gap"
    basis_refs: ["参见 {stability-director}/references/team-knowledge/01-knowledge-index.md §3 Redis 手册"]
    comparison_scope: "事故对象 vs 基线对象（主机/集群/接口）"
    baseline_relation: "字段级（端口/参数） / 现象级（告警/超时） / 因果级（候选→根因）"
    limitations: "基线时效、版本差异、配置漂移、未覆盖对象"
  support_refs: ["E-{incident_id}-..."]
  counterevidence_refs: ["E-{incident_id}-..."]
  counterevidence_status: PRESENT | NONE
```

> **不允许**省略 `basis_refs` 而直接写"基线字段非空"或"文档存在"；亦**不允许**把模型记忆/通用常识填进 `basis_refs`。

## 3. 候选板里引用知识库内容的正确/错误示范

### ✅ 正确

```yaml
candidates:
  - ref: L01
    summary: "Redis RDB 写阻塞导致 fork 耗时飙升"
    evidence_effects:
      - effect: SUPPORTS
        expected_if_true: "事故窗口前后 Redis fork latency 出现明显尖峰，child_oom 出现"
        expected_if_false: "事故窗口前后 fork latency 平直，无 child_oom"
        reference_basis:
          reference_type: baseline_documentation
          basis_refs:
            - "stability-director/references/team-knowledge/01-knowledge-index.md §3 Redis 手册"
            - "用户 raw/00-能力开放平台/02-CRM系统/00-中间件/Redis运维操作手册.md（关于 RDB 与 maxmemory 的配置建议）"
          comparison_scope: "事故实例 aicache 5001 vs 手册基线"
          baseline_relation: 字段级（save、stop-writes-on-bgsave-error）
          limitations: "手册未覆盖 5.0.10 之后的 RDB 行为变化；需现场版本核对"
        support_refs: ["E-{incident}-fork-latency", "E-{incident}-config"]
        counterevidence_refs: []
        counterevidence_status: NONE
```

### ❌ 错误 1：把知识库当现场证据

```yaml
# 错：把知识库路径当 E 编号引用
support_refs:
  - "raw/00-能力开放平台/故障分析/20251125redis异常.md"   # ← 这是历史事故素材，不是 E 编号
```

### ❌ 错误 2：用知识库"缺收录"做排除依据

```yaml
excluded:
  - summary: "排除 ZK 抖动"
    reason: "知识库未收录 ZK 抖动相关事故"
    # 错：未采集、无权限、缺失数据不是排除依据（见 stability-director SKILL.md 第 29 行）
```

### ❌ 错误 3：把恢复成功当成基线已对齐

```yaml
# 错：用户报告"重启 Redis 后恢复"就默认根因已对齐手册
candidates:
  - summary: "Redis 重启即恢复"   # ← 没区分根因和处置动作；见 SKILL.md「恢复成功不能倒推原始根因」
```

## 4. 知识库内容在 P0-P7 各阶段的角色

| 阶段 | 知识库角色 | 允许动作 |
|---|---|---|
| P0 接报分类 | 无（仅看用户上报材料） | 不读 |
| P1 现有材料初析 | **主入口** | 团长读 00-context + 01-knowledge-index，建立 baseline / 历史窗口 / 相邻对象 |
| P2 最小取证 | **缺口催证** | 取证请求里可引用 01 §5 的缺口清单；不引用具体素材作为已有证据 |
| P3 专家分析 | **reference_basis** | 成员读 00-context（环境）+ 各自领域 runbook；按需 Read 知识库原始素材作 baseline |
| P4 候选收敛 | **基础率对照** | 比较"事故现象 vs 知识库历史同类现象"分布，但不替代 E 编号 |
| P5 人工方案 | 仅写"知识库缺口" | 评审卡里可加"建议补充 X 知识到用户仓库" |
| P6 回传验证 | **验证参照** | 验证恢复后指标是否回到知识库 baseline 区间，但不据此认定根因已闭合 |
| P7 交接复盘 | **纳入知识库建议** | 建议用户把本次事故归档到 `raw/02-相关故障/`，更新对应索引页 |

## 5. 跨租户权限边界（与 SKILL.md 第 48 行一致）

> 即使知识库里有相似对象、相邻机房、历史事故的素材，**也不能自动获得对当前事故对象的访问权限**。

- 知识库历史事故的"现象"可作 `comparison_scope`；但"参数值"必须现场采集后才能用。
- 知识库手册的"默认值"可作 `baseline_relation`；但"当前配置"必须现场采集后才能用。
- 用户报告的"和去年那次一样"——只能作为 `reference_basis.reference_type = adjacent_incident` 的入口，仍需独立取证现场证据。

## 6. 知识库更新回灌闭环

每完成一次事故 P7 交接复盘，应**建议用户**（不是自动执行）：

1. 把事故素材按类型归到 `raw/02-相关故障/{A-F}-*.md` 之一的索引页；
2. 在 `INDEX.md` 追加 INC-/CHG- 编号；
3. 标注"已复盘"或"待 P6 验证"状态；
4. 如涉及新中间件集群/新外围接口，扩展 01-knowledge-index.md §4。

专家团**不替代**用户写知识库；只产出建议清单。
